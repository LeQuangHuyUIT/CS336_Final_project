from django.shortcuts import render, redirect

from .models import Photo
from .forms import PhotoForm
# from .retrieval_image import *

# #========================
# import math
# from PIL import Image, ImageOps
# import os
# from glob import glob
# import tensorflow_hub as hub
# import numpy as np
# import tensorflow as tf

# #==========================
# # from .extractor_query import *
# import pickle
# # from PIL import Image, ImageOps
# from scipy.spatial import cKDTree
# from skimage.feature import plot_matches
# from skimage.measure import ransac
# from skimage.transform import AffineTransform

# def get_resized_db_image_paths(destfolder):
#     return sorted(list(glob(os.path.join(destfolder, '*.[Jj][Pp][Gg]'))))

# '''
# load database features
# '''
# name_locations_agg = "./static/locations_agg.npy"
# name_descriptors_agg = "./static/descriptors.npy"
# name_accumulated = "./static/accumulated_indexes_boundaries.pkl"

# # # remember to change image file path to folder contain image
# images_files_path = './static/oxbuild_images'


# # output_path: path to folder feature 
# output_path = ""
# locations_save_path = os.path.join(output_path, name_locations_agg) 
# descriptors_save_path = os.path.join(output_path, name_descriptors_agg)
# accumulated_indexes_boundaries_save_path = os.path.join(output_path, name_accumulated)


# # '''
# # load features
# # '''
# db_images = get_resized_db_image_paths(images_files_path)
# locations_agg = np.load("./mysite/album/locations_agg.npy")
# descriptors_agg = np.load("./mysite/album/descriptors.npy")

# open_file = open("./mysite/album/accumulated_indexes_boundaries.pkl", "rb")
# accumulated_indexes_boundaries = pickle.load(open_file)
# open_file.close()

# '''
# build kdTree
# '''
# dtree = cKDTree(descriptors_agg)

# delf = hub.load('https://tfhub.dev/google/delf/1').signatures['default']

# image_path = "./mysite/static/oxbuild_images/all_souls_000001.jpg"
# image_retrieved_path = retrieval_image(image_path, 20, dtree, descriptors_agg, locations_agg, accumulated_indexes_boundaries, delf)
# print("truy van ngoai ham: ", image_retrieved_path)

def photo_list(request):
    lastphoto = Photo.objects.latest('uploaded_at')

    # image_path = "." + lastphoto.file.url
    # print("image path: ", image_path)
    # image_retrieved_path = retrieval_image(image_path, 20, dtree, descriptors_agg, locations_agg, accumulated_indexes_boundaries, delf)
    # print("truy van trong ham:", image_retrieved_path)

    if request.method == 'POST':
        form = PhotoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('photo_list')
    else:
        form = PhotoForm()
    return render(request, 'album/photo_list.html', {'form': form, 'lastphoto': lastphoto})
