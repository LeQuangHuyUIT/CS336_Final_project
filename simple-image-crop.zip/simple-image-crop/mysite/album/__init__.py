# import os
# from glob import glob
# import numpy as np


# def get_resized_db_image_paths(destfolder):
#     return sorted(list(glob(os.path.join(destfolder, '*.[Jj][Pp][Gg]'))))

# name_locations_agg = "locations_agg.npy"
# name_descriptors_agg = "descriptors.npy"
# name_accumulated = "accumulated_indexes_boundaries.pkl"

# # remember to change image file path to folder contain image
# images_files_path = 'oxbuild_images'


# # output_path: path to folder feature 
# output_path = ""
# locations_save_path = os.path.join(output_path, name_locations_agg) 
# descriptors_save_path = os.path.join(output_path, name_descriptors_agg)
# accumulated_indexes_boundaries_save_path = os.path.join(output_path, name_accumulated)


# '''
# load features
# '''
# db_images = get_resized_db_image_paths(images_files_path)
# locations_agg = np.load(locations_save_path)
# descriptors_agg = np.load(descriptors_save_path)

# open_file = open(accumulated_indexes_boundaries_save_path, "rb")
# accumulated_indexes_boundaries = pickle.load(open_file)
# open_file.close()


# '''
# build kdTree
# '''
# dtree = cKDTree(descriptors_agg)